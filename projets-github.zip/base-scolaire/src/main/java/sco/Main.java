package sco;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

/** Interface en ligne de commande : java -jar target/base-scolaire.jar [--demo] */
public class Main {
    public static void main(String[] args) throws Exception {
        boolean demo = args.length > 0 && args[0].equals("--demo");
        String fichier = demo ? ":memory:" : "base-scolaire.db";

        try (Connection c = Db.ouvrir(fichier)) {
            Db.executerScript(c, "schema.sql");
            Db.executerScript(c, "donnees.sql");
            EtudiantDao dao = new EtudiantDao(c);

            if (demo) {
                System.out.println("== Classement ==");
                dao.classement().forEach(System.out::println);
                dao.noter("SRI-002", "Réseaux", 14);
                System.out.println("\n== Après modification d'une note (SRI-002, Réseaux = 14) ==");
                dao.parFiliere("Système Réseau Informatique").forEach(System.out::println);
                return;
            }
            menu(dao);
        }
    }

    private static void menu(EtudiantDao dao) throws Exception {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("\n1) Classement  2) Étudiants d'une filière  3) Ajouter un étudiant  4) Saisir une note  0) Quitter");
            System.out.print("> ");
            switch (in.nextLine().strip()) {
                case "1" -> afficher(dao.classement());
                case "2" -> {
                    System.out.print("Filière : ");
                    afficher(dao.parFiliere(in.nextLine().strip()));
                }
                case "3" -> {
                    System.out.print("Matricule, nom, prénom, filière (séparés par ;) : ");
                    String[] p = in.nextLine().split(";");
                    dao.ajouter(p[0].strip(), p[1].strip(), p[2].strip(), p[3].strip());
                    System.out.println("Étudiant ajouté.");
                }
                case "4" -> {
                    System.out.print("Matricule ; matière ; note : ");
                    String[] p = in.nextLine().split(";");
                    dao.noter(p[0].strip(), p[1].strip(), Double.parseDouble(p[2].strip().replace(',', '.')));
                    System.out.println("Note enregistrée.");
                }
                case "0" -> { return; }
                default -> System.out.println("Choix invalide.");
            }
        }
    }

    private static void afficher(List<Etudiant> liste) {
        if (liste.isEmpty()) System.out.println("(aucun résultat)");
        liste.forEach(System.out::println);
    }
}
