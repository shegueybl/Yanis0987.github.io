package sco;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/** Connexion JDBC à SQLite et initialisation du schéma. */
public final class Db {
    private Db() {}

    public static Connection ouvrir(String fichier) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:sqlite:" + fichier);
        try (Statement s = c.createStatement()) {
            s.execute("PRAGMA foreign_keys = ON");
        }
        return c;
    }

    /** Exécute un script SQL placé dans src/main/resources. */
    public static void executerScript(Connection c, String ressource) throws SQLException, IOException {
        try (InputStream in = Db.class.getResourceAsStream("/" + ressource)) {
            if (in == null) throw new IOException("Ressource introuvable : " + ressource);
            String sql = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            // Un trigger contient des ';' : on exécute le fichier en un seul bloc via executeScript-like découpage
            for (String instruction : decouper(sql)) {
                try (Statement s = c.createStatement()) {
                    s.execute(instruction);
                }
            }
        }
    }

    /** Découpe un script en instructions en respectant les blocs BEGIN ... END des triggers. */
    static java.util.List<String> decouper(String sql) {
        java.util.List<String> resultat = new java.util.ArrayList<>();
        StringBuilder courant = new StringBuilder();
        boolean dansTrigger = false;
        for (String ligne : sql.split("\n")) {
            String t = ligne.strip();
            if (t.startsWith("--") || t.isEmpty()) continue;
            courant.append(ligne).append('\n');
            if (t.toUpperCase().startsWith("CREATE TRIGGER")) dansTrigger = true;
            boolean fin = dansTrigger ? t.equalsIgnoreCase("END;") : t.endsWith(";");
            if (fin) {
                resultat.add(courant.toString().strip());
                courant.setLength(0);
                dansTrigger = false;
            }
        }
        return resultat;
    }
}
