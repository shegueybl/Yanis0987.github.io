package sco;

/** Un étudiant avec sa moyenne pondérée (issue de la vue v_moyennes). */
public record Etudiant(String matricule, String nom, String prenom, String filiere, double moyenne) {
    @Override
    public String toString() {
        return String.format("%-8s %-10s %-8s %-30s %5.2f", matricule, nom, prenom, filiere, moyenne);
    }
}
