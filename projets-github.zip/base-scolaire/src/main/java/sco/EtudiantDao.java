package sco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Accès aux données : toutes les requêtes sont préparées (pas d'injection SQL). */
public class EtudiantDao {
    private final Connection c;

    public EtudiantDao(Connection c) {
        this.c = c;
    }

    public List<Etudiant> classement() throws SQLException {
        String sql = "SELECT matricule, nom, prenom, filiere, moyenne FROM v_moyennes ORDER BY moyenne DESC";
        List<Etudiant> liste = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) liste.add(lire(rs));
        }
        return liste;
    }

    public List<Etudiant> parFiliere(String filiere) throws SQLException {
        String sql = "SELECT matricule, nom, prenom, filiere, moyenne FROM v_moyennes WHERE filiere = ? ORDER BY nom";
        List<Etudiant> liste = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, filiere);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) liste.add(lire(rs));
            }
        }
        return liste;
    }

    public void ajouter(String matricule, String nom, String prenom, String filiere) throws SQLException {
        String sql = "INSERT INTO etudiants (matricule, nom, prenom, filiere_id) "
                + "VALUES (?, ?, ?, (SELECT id FROM filieres WHERE nom = ?))";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, matricule);
            ps.setString(2, nom);
            ps.setString(3, prenom);
            ps.setString(4, filiere);
            ps.executeUpdate();
        }
    }

    /** Enregistre ou remplace la note d'un étudiant dans une matière. */
    public void noter(String matricule, String matiere, double valeur) throws SQLException {
        String sql = "INSERT INTO notes (etudiant_id, matiere_id, valeur) "
                + "VALUES ((SELECT id FROM etudiants WHERE matricule = ?), (SELECT id FROM matieres WHERE nom = ?), ?) "
                + "ON CONFLICT (etudiant_id, matiere_id) DO UPDATE SET valeur = excluded.valeur";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, matricule);
            ps.setString(2, matiere);
            ps.setDouble(3, valeur);
            ps.executeUpdate();
        }
    }

    private static Etudiant lire(ResultSet rs) throws SQLException {
        return new Etudiant(rs.getString("matricule"), rs.getString("nom"), rs.getString("prenom"),
                rs.getString("filiere"), rs.getDouble("moyenne"));
    }
}
