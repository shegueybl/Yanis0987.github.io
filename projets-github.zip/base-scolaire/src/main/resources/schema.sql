-- Modèle relationnel de la base scolaire
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS filieres (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  nom  TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS etudiants (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  matricule  TEXT NOT NULL UNIQUE,
  nom        TEXT NOT NULL,
  prenom     TEXT NOT NULL,
  filiere_id INTEGER NOT NULL REFERENCES filieres(id)
);

CREATE TABLE IF NOT EXISTS matieres (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  nom         TEXT NOT NULL UNIQUE,
  coefficient INTEGER NOT NULL CHECK (coefficient > 0)
);

CREATE TABLE IF NOT EXISTS notes (
  etudiant_id INTEGER NOT NULL REFERENCES etudiants(id) ON DELETE CASCADE,
  matiere_id  INTEGER NOT NULL REFERENCES matieres(id),
  valeur      REAL    NOT NULL CHECK (valeur BETWEEN 0 AND 20),
  PRIMARY KEY (etudiant_id, matiere_id)
);

-- Moyenne pondérée de chaque étudiant
CREATE VIEW IF NOT EXISTS v_moyennes AS
SELECT e.id AS etudiant_id, e.matricule, e.nom, e.prenom, f.nom AS filiere,
       ROUND(SUM(n.valeur * m.coefficient) * 1.0 / SUM(m.coefficient), 2) AS moyenne
FROM etudiants e
JOIN filieres f ON f.id = e.filiere_id
JOIN notes n    ON n.etudiant_id = e.id
JOIN matieres m ON m.id = n.matiere_id
GROUP BY e.id;

-- Refuse toute modification de note en dehors de l'intervalle [0, 20]
CREATE TRIGGER IF NOT EXISTS trg_note_valide
BEFORE UPDATE OF valeur ON notes
WHEN NEW.valeur < 0 OR NEW.valeur > 20
BEGIN
  SELECT RAISE(ABORT, 'La note doit être comprise entre 0 et 20');
END;
