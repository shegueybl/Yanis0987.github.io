-- Données d'exemple (fictives)
INSERT OR IGNORE INTO filieres (nom) VALUES ('Système Réseau Informatique'), ('Génie Logiciel');

INSERT OR IGNORE INTO matieres (nom, coefficient) VALUES
  ('Programmation Java', 4), ('Bases de données SQL', 3), ('Réseaux', 3), ('Systèmes Linux', 3), ('Anglais', 1);

INSERT OR IGNORE INTO etudiants (matricule, nom, prenom, filiere_id) VALUES
  ('SRI-001', 'Kossi',   'Ama',    1),
  ('SRI-002', 'Mensah',  'Koffi',  1),
  ('SRI-003', 'Agbeko',  'Edem',   1),
  ('GL-001',  'Lawson',  'Afi',    2);

INSERT OR IGNORE INTO notes (etudiant_id, matiere_id, valeur) VALUES
  (1,1,15.5),(1,2,14),(1,3,16),(1,4,13),(1,5,12),
  (2,1,11),(2,2,13.5),(2,3,10),(2,4,15),(2,5,14),
  (3,1,17),(3,2,16),(3,3,15),(3,4,18),(3,5,13),
  (4,1,12),(4,2,12),(4,3,9),(4,4,11),(4,5,15);
