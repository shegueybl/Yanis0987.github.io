# Base scolaire

Application Java en ligne de commande connectée à une base **SQL** (SQLite) via **JDBC**.
Elle gère les étudiants, les filières, les matières et les notes, et calcule les moyennes pondérées.

## Modèle de données

```
filieres (id, nom)
etudiants (id, matricule, nom, prenom, filiere_id → filieres)
matieres (id, nom, coefficient)
notes (etudiant_id → etudiants, matiere_id → matieres, valeur)   clé primaire (etudiant_id, matiere_id)
v_moyennes : vue qui calcule la moyenne pondérée de chaque étudiant
```

Contraintes : clés étrangères, `CHECK` sur les notes (0 à 20) et sur les coefficients, trigger qui refuse
une modification de note hors de l'intervalle.

## Lancer le projet

Java 17 ou plus récent et Maven.

```bash
mvn package
java -jar target/base-scolaire.jar --demo   # démonstration sur une base en mémoire
java -jar target/base-scolaire.jar          # menu interactif, base dans base-scolaire.db
```

## Structure

- `src/main/resources/schema.sql` : tables, vue et trigger
- `src/main/resources/donnees.sql` : données d'exemple (fictives)
- `sql/requetes.sql` : jointures, agrégations, fonction de fenêtrage et sous-requêtes à tester
- `src/main/java/sco/Db.java` : connexion JDBC et exécution des scripts
- `src/main/java/sco/EtudiantDao.java` : requêtes préparées (protégées contre l'injection SQL)
- `src/main/java/sco/Main.java` : menu en ligne de commande
