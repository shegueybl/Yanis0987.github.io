-- Requêtes utiles, à tester avec : sqlite3 base-scolaire.db < sql/requetes.sql

-- 1. Classement général (vue v_moyennes)
SELECT RANK() OVER (ORDER BY moyenne DESC) AS rang, matricule, nom, prenom, moyenne
FROM v_moyennes;

-- 2. Moyenne par filière (jointure + agrégation)
SELECT filiere, COUNT(*) AS effectif, ROUND(AVG(moyenne), 2) AS moyenne_filiere
FROM v_moyennes
GROUP BY filiere;

-- 3. Étudiants sous la moyenne dans au moins une matière
SELECT DISTINCT e.nom, e.prenom, m.nom AS matiere, n.valeur
FROM notes n
JOIN etudiants e ON e.id = n.etudiant_id
JOIN matieres m  ON m.id = n.matiere_id
WHERE n.valeur < 10
ORDER BY e.nom;

-- 4. Meilleure note de chaque matière (sous-requête)
SELECT m.nom AS matiere, e.nom, e.prenom, n.valeur
FROM notes n
JOIN matieres m  ON m.id = n.matiere_id
JOIN etudiants e ON e.id = n.etudiant_id
WHERE n.valeur = (SELECT MAX(valeur) FROM notes WHERE matiere_id = n.matiere_id);
