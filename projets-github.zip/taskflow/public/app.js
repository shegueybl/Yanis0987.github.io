const liste = document.getElementById('liste');
const erreur = document.getElementById('erreur');
let filtre = 'toutes';

async function api(url, options) {
  const rep = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!rep.ok) throw new Error((await rep.json()).erreur || 'Erreur serveur');
  return rep.status === 204 ? null : rep.json();
}

function afficher(taches) {
  liste.replaceChildren(...taches.map((t) => {
    const li = document.createElement('li');
    li.className = t.fait ? 'fait' : '';
    const coche = Object.assign(document.createElement('input'), { type: 'checkbox', checked: !!t.fait });
    coche.addEventListener('change', async () => { await api(`/api/taches/${t.id}`, { method: 'PATCH', body: JSON.stringify({ fait: coche.checked }) }); charger(); });
    const texte = document.createElement('span');
    texte.textContent = t.titre;
    const date = document.createElement('time');
    date.textContent = t.echeance || '';
    const suppr = Object.assign(document.createElement('button'), { textContent: '×', title: 'Supprimer' });
    suppr.addEventListener('click', async () => { await api(`/api/taches/${t.id}`, { method: 'DELETE' }); charger(); });
    li.append(coche, texte, date, suppr);
    return li;
  }));
  if (!taches.length) liste.innerHTML = '<li class="vide">Rien ici pour le moment.</li>';
}

async function charger() { afficher(await api(`/api/taches?filtre=${filtre}`)); }

document.getElementById('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  erreur.textContent = '';
  try {
    await api('/api/taches', { method: 'POST', body: JSON.stringify({ titre: titre.value, echeance: echeance.value }) });
    e.target.reset();
    charger();
  } catch (err) { erreur.textContent = err.message; }
});

document.getElementById('filtres').addEventListener('click', (e) => {
  if (!e.target.dataset.f) return;
  filtre = e.target.dataset.f;
  document.querySelectorAll('#filtres button').forEach((b) => b.classList.toggle('actif', b === e.target));
  charger();
});

charger();
