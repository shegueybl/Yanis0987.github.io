# Taskflow

Application web de gestion de tâches : création, suivi et échéances.
Serveur **Node.js**, base de données **SQL** (SQLite) et interface en **HTML, CSS et JavaScript**.

## Lancer le projet

Node.js 22.13 ou plus récent. Aucune dépendance à installer.

```bash
npm start        # http://localhost:3000
npm test         # tests de l'API
```

## API

| Méthode | Route | Rôle |
|---|---|---|
| GET | `/api/taches?filtre=toutes\|afaire\|enRetard\|faites` | Lister les tâches |
| POST | `/api/taches` | Créer une tâche `{ "titre": "...", "echeance": "AAAA-MM-JJ" }` |
| PATCH | `/api/taches/:id` | Marquer comme faite `{ "fait": true }` |
| DELETE | `/api/taches/:id` | Supprimer |

## Structure

- `schema.sql` : table `taches` et index
- `db.js` : accès SQL avec requêtes préparées
- `server.js` : routes et validation
- `public/` : interface
