-- Schéma de la base Taskflow
CREATE TABLE IF NOT EXISTS taches (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  titre      TEXT    NOT NULL CHECK (length(titre) BETWEEN 1 AND 120),
  echeance   TEXT,                                  -- date ISO : AAAA-MM-JJ
  fait       INTEGER NOT NULL DEFAULT 0 CHECK (fait IN (0, 1)),
  cree_le    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_taches_echeance ON taches (fait, echeance);
