// Serveur HTTP de Taskflow : API REST (JSON) + fichiers statiques
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { ouvrirBase, creerDepot } = require('./db');

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
};

function repondre(res, code, donnees) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(donnees === undefined ? '' : JSON.stringify(donnees));
}

function lireCorps(req) {
  return new Promise((resolve, reject) => {
    let corps = '';
    req.on('data', (morceau) => {
      corps += morceau;
      if (corps.length > 10_000) { reject(new Error('Corps trop volumineux')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(corps ? JSON.parse(corps) : {}); } catch { reject(new Error('JSON invalide')); }
    });
  });
}

function dateValide(texte) {
  return /^\d{4}-\d{2}-\d{2}$/.test(texte) && !Number.isNaN(Date.parse(texte));
}

function creerServeur(depot) {
  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    try {
      if (url.pathname === '/api/taches' && req.method === 'GET') {
        return repondre(res, 200, depot.lister(url.searchParams.get('filtre') || 'toutes'));
      }
      if (url.pathname === '/api/taches' && req.method === 'POST') {
        const { titre, echeance } = await lireCorps(req);
        if (typeof titre !== 'string' || !titre.trim() || titre.trim().length > 120) {
          return repondre(res, 400, { erreur: 'Le titre est obligatoire (120 caractères maximum).' });
        }
        if (echeance && !dateValide(echeance)) {
          return repondre(res, 400, { erreur: "L'échéance doit être au format AAAA-MM-JJ." });
        }
        return repondre(res, 201, depot.ajouter(titre.trim(), echeance));
      }
      const m = url.pathname.match(/^\/api\/taches\/(\d+)$/);
      if (m && req.method === 'PATCH') {
        const { fait } = await lireCorps(req);
        const tache = depot.changerEtat(Number(m[1]), Boolean(fait));
        return tache ? repondre(res, 200, tache) : repondre(res, 404, { erreur: 'Tâche introuvable.' });
      }
      if (m && req.method === 'DELETE') {
        return depot.supprimer(Number(m[1])) ? repondre(res, 204) : repondre(res, 404, { erreur: 'Tâche introuvable.' });
      }
      if (req.method === 'GET') {
        const nom = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
        const fichier = path.join(__dirname, 'public', path.normalize(nom));
        if (fichier.startsWith(path.join(__dirname, 'public')) && fs.existsSync(fichier) && fs.statSync(fichier).isFile()) {
          res.writeHead(200, { 'Content-Type': TYPES[path.extname(fichier)] || 'application/octet-stream' });
          return fs.createReadStream(fichier).pipe(res);
        }
      }
      repondre(res, 404, { erreur: 'Route inconnue.' });
    } catch (e) {
      repondre(res, 400, { erreur: e.message });
    }
  });
}

module.exports = { creerServeur };

if (require.main === module) {
  const port = process.env.PORT || 3000;
  creerServeur(creerDepot(ouvrirBase())).listen(port, () => {
    console.log(`Taskflow disponible sur http://localhost:${port}`);
  });
}
