// Tests de l'API avec le module de test intégré à Node.js : npm test
const test = require('node:test');
const assert = require('node:assert');
const { ouvrirBase, creerDepot } = require('./db');
const { creerServeur } = require('./server');

test('cycle de vie complet d\'une tâche', async () => {
  const serveur = creerServeur(creerDepot(ouvrirBase(':memory:')));
  await new Promise((r) => serveur.listen(0, r));
  const base = `http://localhost:${serveur.address().port}/api/taches`;
  const json = (m, url, corps) => fetch(url, { method: m, headers: { 'Content-Type': 'application/json' }, body: corps && JSON.stringify(corps) });

  let rep = await json('POST', base, { titre: 'Réviser le cours de SQL', echeance: '2099-01-31' });
  assert.strictEqual(rep.status, 201);
  const tache = await rep.json();
  assert.strictEqual(tache.fait, 0);

  assert.strictEqual((await json('POST', base, { titre: '' })).status, 400);
  assert.strictEqual((await json('POST', base, { titre: 'x', echeance: 'demain' })).status, 400);

  rep = await json('PATCH', `${base}/${tache.id}`, { fait: true });
  assert.strictEqual((await rep.json()).fait, 1);
  assert.strictEqual((await (await fetch(`${base}?filtre=faites`)).json()).length, 1);
  assert.strictEqual((await (await fetch(`${base}?filtre=afaire`)).json()).length, 0);

  assert.strictEqual((await json('DELETE', `${base}/${tache.id}`)).status, 204);
  assert.strictEqual((await json('DELETE', `${base}/${tache.id}`)).status, 404);
  serveur.close();
});
