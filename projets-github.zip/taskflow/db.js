// Accès à la base SQLite (module intégré à Node.js, aucune dépendance à installer)
const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

function ouvrirBase(fichier = path.join(__dirname, 'taskflow.db')) {
  const db = new DatabaseSync(fichier);
  db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
  return db;
}

function creerDepot(db) {
  const lister = {
    toutes: db.prepare('SELECT * FROM taches ORDER BY fait, echeance IS NULL, echeance, id'),
    faites: db.prepare('SELECT * FROM taches WHERE fait = 1 ORDER BY echeance, id'),
    afaire: db.prepare('SELECT * FROM taches WHERE fait = 0 ORDER BY echeance IS NULL, echeance, id'),
    enRetard: db.prepare(
      "SELECT * FROM taches WHERE fait = 0 AND echeance IS NOT NULL AND echeance < date('now') ORDER BY echeance"
    ),
  };
  const ajouter = db.prepare('INSERT INTO taches (titre, echeance) VALUES (?, ?)');
  const trouver = db.prepare('SELECT * FROM taches WHERE id = ?');
  const majEtat = db.prepare('UPDATE taches SET fait = ? WHERE id = ?');
  const supprimer = db.prepare('DELETE FROM taches WHERE id = ?');

  return {
    lister: (filtre = 'toutes') => (lister[filtre] || lister.toutes).all(),
    ajouter: (titre, echeance) => trouver.get(ajouter.run(titre, echeance || null).lastInsertRowid),
    changerEtat: (id, fait) => (majEtat.run(fait ? 1 : 0, id).changes ? trouver.get(id) : null),
    supprimer: (id) => supprimer.run(id).changes > 0,
  };
}

module.exports = { ouvrirBase, creerDepot };
