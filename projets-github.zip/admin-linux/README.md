# Administration Linux

Scripts shell pour administrer un serveur Linux (testés sous Debian/Ubuntu) :
comptes et droits, accès SSH sécurisé, sauvegardes automatiques et surveillance des services.

| Script | Rôle |
|---|---|
| `scripts/creer-utilisateurs.sh` | Crée groupes et comptes depuis un CSV, dossier personnel en `750`, mot de passe à changer à la première connexion |
| `scripts/durcir-ssh.sh` | Interdit root et les mots de passe SSH, valide la configuration avant de recharger |
| `scripts/sauvegarde.sh` | Archive `tar.gz` avec somme de contrôle SHA-256 et rotation des anciennes archives |
| `scripts/verifier-services.sh` | Vérifie des services systemd et relance ceux qui sont arrêtés |

## Utilisation

```bash
# Simulation d'abord, puis création réelle
./scripts/creer-utilisateurs.sh --dry-run config/utilisateurs.csv
sudo ./scripts/creer-utilisateurs.sh config/utilisateurs.csv

# Durcissement SSH (installe d'abord ta clé publique avec ssh-copy-id)
sudo ./scripts/durcir-ssh.sh

# Sauvegarde manuelle
sudo ./scripts/sauvegarde.sh

# Surveillance
sudo ./scripts/verifier-services.sh ssh cron
```

## Sauvegarde automatique

Copier le dossier dans `/opt/admin-linux`, puis :

```bash
sudo cp systemd/sauvegarde.* /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now sauvegarde.timer
systemctl list-timers sauvegarde.timer
```

Restaurer : `tar -xzf sauvegarde-AAAAMMJJ-HHMMSS.tar.gz -C /` après avoir vérifié la somme avec `sha256sum -c`.
