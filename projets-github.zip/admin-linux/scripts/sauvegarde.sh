#!/usr/bin/env bash
# Sauvegarde des dossiers listés dans config/sauvegarde.conf, avec rotation des archives.
# Usage : ./sauvegarde.sh [fichier.conf]
# Variables du fichier de configuration : SOURCES (tableau), DESTINATION, CONSERVER (nombre d'archives).
set -euo pipefail

CONF="${1:-$(dirname "$0")/../config/sauvegarde.conf}"
# shellcheck source=/dev/null
source "${CONF}"

HORODATAGE="$(date +%Y%m%d-%H%M%S)"
ARCHIVE="${DESTINATION}/sauvegarde-${HORODATAGE}.tar.gz"
mkdir -p "${DESTINATION}"

log() { echo "$(date '+%F %T') $*"; }

log "Début de la sauvegarde vers ${ARCHIVE}"
tar --create --gzip --file "${ARCHIVE}" --ignore-failed-read "${SOURCES[@]}" 2>/dev/null || true
if ! gzip --test "${ARCHIVE}"; then
  log "ERREUR : l'archive est corrompue" >&2
  exit 1
fi
sha256sum "${ARCHIVE}" > "${ARCHIVE}.sha256"
log "Archive créée ($(du -h "${ARCHIVE}" | cut -f1))"

# Rotation : on ne garde que les N archives les plus récentes
mapfile -t ANCIENNES < <(ls -1t "${DESTINATION}"/sauvegarde-*.tar.gz | tail -n +$((CONSERVER + 1)))
for ancienne in "${ANCIENNES[@]}"; do
  rm -f -- "${ancienne}" "${ancienne}.sha256"
  log "Ancienne archive supprimée : $(basename "${ancienne}")"
done
log "Terminé"
