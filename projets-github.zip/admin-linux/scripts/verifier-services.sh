#!/usr/bin/env bash
# Vérifie des services systemd et tente de relancer ceux qui sont arrêtés.
# Usage : sudo ./verifier-services.sh ssh cron rsyslog
set -uo pipefail

(( $# > 0 )) || { echo "Usage : $0 service [service...]" >&2; exit 2; }
code=0

for service in "$@"; do
  if systemctl is-active --quiet "${service}"; then
    echo "OK     ${service}"
  else
    echo "ARRÊT  ${service} : tentative de redémarrage"
    if systemctl restart "${service}" && systemctl is-active --quiet "${service}"; then
      echo "OK     ${service} (relancé)"
    else
      echo "ÉCHEC  ${service}" >&2
      code=1
    fi
  fi
done
exit "${code}"
