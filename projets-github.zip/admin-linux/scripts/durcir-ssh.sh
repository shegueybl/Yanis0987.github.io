#!/usr/bin/env bash
# Durcit la configuration du serveur SSH : pas de connexion root, authentification par clé uniquement.
# ATTENTION : vérifie que ta clé publique est installée avant de lancer ce script, sinon tu perds l'accès.
# Usage : sudo ./durcir-ssh.sh
set -euo pipefail

(( EUID == 0 )) || { echo "Lance ce script avec sudo." >&2; exit 1; }

FICHIER=/etc/ssh/sshd_config.d/99-durcissement.conf
SAUVEGARDE="${FICHIER}.bak"

[[ -f "${FICHIER}" ]] && cp "${FICHIER}" "${SAUVEGARDE}"

cat > "${FICHIER}" <<'CONF'
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
PermitEmptyPasswords no
MaxAuthTries 3
LoginGraceTime 30
X11Forwarding no
CONF

# On ne recharge SSH que si la configuration est valide
if sshd -t; then
  systemctl reload ssh 2>/dev/null || systemctl reload sshd
  echo "Configuration SSH durcie et rechargée."
else
  echo "Configuration invalide, retour en arrière." >&2
  if [[ -f "${SAUVEGARDE}" ]]; then mv "${SAUVEGARDE}" "${FICHIER}"; else rm -f "${FICHIER}"; fi
  exit 1
fi
