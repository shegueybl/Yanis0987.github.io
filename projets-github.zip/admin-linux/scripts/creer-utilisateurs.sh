#!/usr/bin/env bash
# Crée les groupes et les comptes décrits dans un fichier CSV (login;groupe;shell).
# Usage : sudo ./creer-utilisateurs.sh [--dry-run] config/utilisateurs.csv
set -euo pipefail

DRY_RUN=0
if [[ "${1:-}" == "--dry-run" ]]; then DRY_RUN=1; shift; fi
FICHIER="${1:?Usage : $0 [--dry-run] fichier.csv}"

run() {
  if (( DRY_RUN )); then echo "[dry-run] $*"; else "$@"; fi
}

if (( ! DRY_RUN && EUID != 0 )); then
  echo "Ce script doit être lancé avec sudo (ou avec --dry-run)." >&2
  exit 1
fi

while IFS=';' read -r login groupe shell; do
  [[ -z "${login}" || "${login}" == \#* ]] && continue
  shell="${shell:-/bin/bash}"

  if ! getent group "${groupe}" >/dev/null; then
    run groupadd "${groupe}"
  fi

  if id "${login}" >/dev/null 2>&1; then
    echo "= ${login} existe déjà, ignoré"
    continue
  fi

  run useradd --create-home --gid "${groupe}" --shell "${shell}" "${login}"
  run chmod 750 "/home/${login}"             # le dossier personnel n'est lisible que par son groupe
  run passwd --expire "${login}"             # mot de passe à définir à la première connexion
  echo "+ ${login} créé (groupe ${groupe})"
done < "${FICHIER}"
