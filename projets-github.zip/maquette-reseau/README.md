# Maquette réseau

Maquette d'un réseau d'établissement : **plan d'adressage VLSM**, **VLAN**, **routage inter-VLAN** et
**pare-feu** sur un routeur Linux. Les configurations sont prêtes à être appliquées dans une maquette
virtuelle (VirtualBox, GNS3, Packet Tracer pour le switch).

## Topologie

```mermaid
flowchart LR
  Internet((Internet)) --- WAN[eth1 · WAN]
  subgraph Routeur Linux
    WAN --- R{{Routage + nftables + dnsmasq}}
    R --- TRUNK[eth0 · trunk 802.1Q]
  end
  TRUNK --- SW[Switch]
  SW --- V10[VLAN 10 · Étudiants]
  SW --- V20[VLAN 20 · Administration]
  SW --- V30[VLAN 30 · Serveurs]
  SW --- V40[VLAN 40 · Invités]
```

## Plan d'adressage (réseau de base 192.168.10.0/24)

Généré par `npm run plan` : les sous-réseaux sont attribués du plus grand au plus petit pour ne pas gaspiller d'adresses.

| Réseau | Service | Hôtes demandés | Masque | Plage utilisable | Diffusion | Capacité |
|---|---|---|---|---|---|---|
| 192.168.10.0/25 | Étudiants | 100 | 255.255.255.128 | 192.168.10.1 à 192.168.10.126 | 192.168.10.127 | 126 |
| 192.168.10.128/26 | Administration | 50 | 255.255.255.192 | 192.168.10.129 à 192.168.10.190 | 192.168.10.191 | 62 |
| 192.168.10.192/27 | Serveurs | 20 | 255.255.255.224 | 192.168.10.193 à 192.168.10.222 | 192.168.10.223 | 30 |
| 192.168.10.224/28 | Invités | 10 | 255.255.255.240 | 192.168.10.225 à 192.168.10.238 | 192.168.10.239 | 14 |

| VLAN | Service | Passerelle (routeur) |
|---|---|---|
| 10 | Étudiants | 192.168.10.1 |
| 20 | Administration | 192.168.10.129 |
| 30 | Serveurs | 192.168.10.193 |
| 40 | Invités | 192.168.10.225 |

Il reste 16 adresses libres (192.168.10.240/28) pour de futures liaisons.

## Politique d'accès

| Source ↓ / Destination → | Serveurs | Internet | Autres VLAN |
|---|---|---|---|
| Administration | tout | oui | non |
| Étudiants | web (80, 443) | oui | non |
| Serveurs | — | oui (mises à jour) | non |
| Invités | non | oui | non |

SSH sur le routeur : uniquement depuis le VLAN Administration.

## Mise en place sur le routeur Linux

```bash
sudo cp configs/01-routeur-netplan.yaml /etc/netplan/ && sudo netplan apply
sudo cp configs/99-routage.conf /etc/sysctl.d/ && sudo sysctl --system
sudo cp configs/nftables.conf /etc/nftables.conf && sudo nft -c -f /etc/nftables.conf && sudo systemctl enable --now nftables
sudo cp configs/dnsmasq.conf /etc/dnsmasq.d/maquette.conf && sudo systemctl restart dnsmasq
```

La configuration du switch est dans `configs/switch-vlan.txt`.

## Vérifier

```bash
ip -br addr                       # les 4 interfaces vlanXX ont leur adresse
sudo nft list ruleset             # règles chargées
ping 192.168.10.193               # depuis un poste Étudiants : doit répondre (ICMP vers la passerelle)
curl http://192.168.10.194        # depuis un poste Étudiants vers un serveur web : autorisé
ssh admin@192.168.10.193          # depuis un poste Étudiants : doit être bloqué
```

## Outil de calcul

```bash
npm run plan     # affiche le plan VLSM
npm test         # tests du calculateur
node outils/vlsm.js 10.0.0.0/22 "Labo=200" "Bureaux=120" "Serveurs=30"
```
