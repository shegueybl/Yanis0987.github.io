#!/usr/bin/env node
// Calcule un plan d'adressage VLSM à partir d'un réseau de base et des besoins de chaque service.
// Usage : node outils/vlsm.js 192.168.10.0/24 "Étudiants=100" "Administration=50" "Serveurs=20" "Invités=10"

const versEntier = (ip) => ip.split('.').reduce((n, o) => n * 256 + Number(o), 0);
const versIp = (n) => [24, 16, 8, 0].map((d) => Math.floor(n / 2 ** d) % 256).join('.');

/** Plus petit préfixe CIDR pouvant contenir `hotes` machines (+ adresse réseau et diffusion). */
function prefixePour(hotes) {
  let bits = 2;
  while (2 ** bits - 2 < hotes) bits++;
  return 32 - bits;
}

function planifier(base, besoins) {
  const [adresse, prefixeBase] = base.split('/');
  const debut = versEntier(adresse);
  const fin = debut + 2 ** (32 - Number(prefixeBase));
  let courant = debut;
  const plan = [...besoins].sort((a, b) => b.hotes - a.hotes).map(({ nom, hotes }) => {
    const prefixe = prefixePour(hotes);
    const taille = 2 ** (32 - prefixe);
    if (courant + taille > fin) throw new Error(`Plus de place dans ${base} pour « ${nom} » (${hotes} hôtes).`);
    const reseau = courant;
    courant += taille;
    return {
      nom, hotes, reseau: `${versIp(reseau)}/${prefixe}`, masque: versIp(2 ** 32 - taille),
      passerelle: versIp(reseau + 1), premier: versIp(reseau + 1), dernier: versIp(reseau + taille - 2),
      diffusion: versIp(reseau + taille - 1), capacite: taille - 2,
    };
  });
  return { plan, libres: fin - courant };
}

module.exports = { planifier, prefixePour };

if (require.main === module) {
  const [base, ...args] = process.argv.slice(2);
  if (!base || !args.length) {
    console.error('Usage : node outils/vlsm.js 192.168.10.0/24 "Étudiants=100" "Serveurs=20"');
    process.exit(2);
  }
  const besoins = args.map((a) => { const [nom, h] = a.split('='); return { nom, hotes: Number(h) }; });
  const { plan, libres } = planifier(base, besoins);
  console.log('| Réseau | Service | Hôtes demandés | Masque | Plage utilisable | Diffusion | Capacité |');
  console.log('|---|---|---|---|---|---|---|');
  for (const p of plan) {
    console.log(`| ${p.reseau} | ${p.nom} | ${p.hotes} | ${p.masque} | ${p.premier} à ${p.dernier} | ${p.diffusion} | ${p.capacite} |`);
  }
  console.log(`\nAdresses encore libres dans ${base} : ${libres}`);
}
