const test = require('node:test');
const assert = require('node:assert');
const { planifier, prefixePour } = require('./vlsm');

test('préfixes CIDR', () => {
  assert.strictEqual(prefixePour(100), 25);
  assert.strictEqual(prefixePour(50), 26);
  assert.strictEqual(prefixePour(20), 27);
  assert.strictEqual(prefixePour(10), 28);
  assert.strictEqual(prefixePour(2), 30);
});

test('plan VLSM sans chevauchement', () => {
  const { plan, libres } = planifier('192.168.10.0/24', [
    { nom: 'Invités', hotes: 10 }, { nom: 'Étudiants', hotes: 100 }, { nom: 'Serveurs', hotes: 20 }, { nom: 'Administration', hotes: 50 },
  ]);
  assert.deepStrictEqual(plan.map((p) => p.reseau), ['192.168.10.0/25', '192.168.10.128/26', '192.168.10.192/27', '192.168.10.224/28']);
  assert.strictEqual(libres, 16);
});

test('refuse un plan trop grand', () => {
  assert.throws(() => planifier('192.168.10.0/24', [{ nom: 'A', hotes: 200 }, { nom: 'B', hotes: 100 }]));
});
